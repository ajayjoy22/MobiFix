package com.project.myhelper;

public class Feedback_values {

    public String Email,Text;

    public Feedback_values(){
    }

    public Feedback_values(String email, String text) {
        this.Email = email;
        this.Text=text;
    }
}
