# My-Helper - an android application

It can used by any Android Phone to get full access to your phone. Any phone with basic sms feature can be used to access your phone. Suppose your phone got lost or you forgot your mobile at your home then you can do following -

1) You can get contact numbers from your phone contacts by sending msg in specific format to your mobile number then your mobile will send you contact number.
2) A sms can help you change the sound profile of your phone (silent to normal).
3) It help you to get location of your mobile.
4) It can lock your mobile if mobile doesn't have.
And many more.

<br>
<br>

NOTE : This application may not work in some android device because of some security reasons.

<br>
<br>


SCREENSHOTS : 

<p align="center"><img src="https://user-images.githubusercontent.com/38532316/84913169-da96e200-b0d7-11ea-9577-8b505608eba7.png" width="300" height="500"></p>

login page                            |   registration page
:-----------------------------------: | :----------------------------------:
<img src="https://user-images.githubusercontent.com/38532316/84911871-660f7380-b0d6-11ea-9946-e4f3f9deb534.png" width="300" height="500"> | <img src="https://user-images.githubusercontent.com/38532316/84913154-d8348800-b0d7-11ea-8753-82009a23dc27.png" width="300" height="500"> 

Home page                            |   Navigation page
:-----------------------------------: | :----------------------------------:
<img src="https://user-images.githubusercontent.com/38532316/84913191-e1bdf000-b0d7-11ea-8ba7-fc98e877064b.png" width="300" height="500"> | <img src="https://user-images.githubusercontent.com/38532316/84915811-e932c880-b0da-11ea-8007-a50d56952511.png" width="300" height="500"> 


<br>
<br>
<br>


HOW TO USE :-

1) Firstly you need to check that my helper is working on your phone or not. For that send the message to your phone number like that :

<img src="https://user-images.githubusercontent.com/38532316/84916430-b6d59b00-b0db-11ea-9914-19068e6b443b.jpg" width="500" height="350"> 

If you get reply then it is working fine.

<br>
<br>
<br>

2) For getting contact number from your phone contacts, send sms in a given format :
      
      myhelper &lt;your login password> getcontact &lt;contact name>
  
  for example

<img src="https://user-images.githubusercontent.com/38532316/84917577-2304ce80-b0dd-11ea-8b49-20eb01ac4425.png" width="500" height="200"> 

<br>
<br>
<br>

You can take help like this :


<br>
<br>

<img src="https://user-images.githubusercontent.com/38532316/84918561-614ebd80-b0de-11ea-8240-e0ac274d14e1.jpg" width="500" height="700">

